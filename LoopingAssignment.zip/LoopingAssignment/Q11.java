package LoopingAssignment;

public class Q11 {

	public static void main(String[] args) {
		int i=1;
		while(i<=100)//1<=100//2<=100
		{
			if(i==77)//1==77 false
			{
				break;
			}
			if(i%3==0 && i%5==0) //1%3==1 1%5=1//1==1 false
			{
				i++;
				continue;
			}
			System.out.println(i);//1//2
			i++;//2//3
		}
		
	}

}
