package LoopingAssignment;

public class Q13 {

	public static void main(String[] args) {

		int num=5637;
		int count=0;
		
		while(num>0)//5637>0
		{
			int digit=num % 10;//digit=5637%10=7//563%10=3//56%10=6 f//5%10=5T
			
			if(digit==5 || digit==3 ||digit==7)//digit=7 T//3 t//5
			{
				count++;//1//2//3
			}
			num=num/10;//num=5637/10=7//563//56//56/10=5//5/10=0
		}
		
		System.out.println("Count of prime numbers in an entered number is " +count);//3
	}

}
