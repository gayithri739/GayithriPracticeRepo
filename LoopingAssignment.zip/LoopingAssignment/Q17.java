package LoopingAssignment;

import java.util.Scanner;

public class Q17 {

	public static void main(String[] args) {
		//Revers of number using do while
		
		int num;
		int rev=0;
		
		System.out.println("Enter a number : ");
		Scanner sc=new Scanner(System.in);
		num=sc.nextInt();
		//First reverse the number and then print left to right
		
		//Reverse the number
		do
		{
			int d=num%10;//128%10=8//12%10=2//1%10=1//
			rev=rev*10+d;//rev=0*10+8=8//0*10+2==2//0*10+1=1
			num=num/10;//128/10=12//12/10=1//1/10=0
			
		}while(num!=0);
		//System.out.println(rev);
		
		//Print digit from left to write
		do
		{
			int d=rev%10;//821%10=1//82%10=2//8%10=8
			
			System.out.print(d + " ");//1//2//8
			rev=rev/10;//821/10=82//82/10=8//
			
			
		}while(rev!=0);

	}

}
