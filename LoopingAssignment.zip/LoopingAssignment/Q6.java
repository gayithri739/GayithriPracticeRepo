package LoopingAssignment;

import java.util.Scanner;

public class Q6 {

	public static void main(String[] args) {
		int M,C,P;
		
		Scanner sc=new Scanner(System.in);
		System.out.println("Enter Physics marks");
		P=sc.nextInt();
		
		System.out.println("Enter Chemistry marks");
		C=sc.nextInt();
		
		System.out.println("Enter Maths marks");
		M=sc.nextInt();
		
		int Total=P+C+M;
		int MP=M+P;
		
		if(M>=60)
		{
			if(P>=50)
			{
				if(C>=40)
				{
					if(Total>=180||MP>=120)
					{
						System.out.println("Eligible for physics hons");
					}
					else 
					{
						System.out.println("Not eligible");
					}
				}
					else 
					{
						System.out.println("Not eligible");
					}
				}
					else
					{
						System.out.println("Not eligible");
					}
			}
			}
		}
	

		
	


