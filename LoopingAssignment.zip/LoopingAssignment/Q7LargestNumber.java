package LoopingAssignment;

import java.util.Scanner;

public class Q7LargestNumber {

	public static void main(String[] args) {
		
		int a,b,c,d;
		Scanner sc=new Scanner(System.in);
		System.out.println("Enter the value of a");
		a=sc.nextInt();
		
		System.out.println("Enter the value of b");
		b=sc.nextInt();
		
		System.out.println("Enter the value of c");
		c=sc.nextInt();
		
		System.out.println("Enter the value of d");
		d=sc.nextInt();
		
		if(a>=b)
		{
			if(a>=c)
			{
				if(a>=d)
				{
					System.out.println("a is largest");
				}
				else
				{
					System.out.println("d is largest");
				}
			}
			else
		
	            {
	                if (c >= d) 
	                {
	                    System.out.println("c is largest");
	                } else 
	                {
	                    System.out.println("d is largest");
	                }
	            }
	        }
	        else
			{

				if(b>=c)
				{
					if(b>=d)
					{
					System.out.println("b is largest");
					}
				else
					{
					System.out.println("d is largest");
					}
				}
				
			else
			{
				if(c>=d)
				{
					System.out.println("c is largest");
				}
				else
				{
					System.out.println("d is largest");
				}
			}
		}
	}
	
}

		

	


