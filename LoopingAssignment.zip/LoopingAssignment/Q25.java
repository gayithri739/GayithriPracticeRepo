package LoopingAssignment;

public class Q25 {

	public static void main(String[] args) {
		
		//perfect number is sum of the divisor is equal to same number 
		//ex: 6 divisors are 1,2,3 sum of theses divisors=6
		
		System.out.println("Proper Perfect numbers between 1 to 1000 are : ");
		for(int num=1;num<=10000;num++)
		{
			int sum=0;
			for( int i=1;i<num;i++)
			{
				if(num % i==0)
				{
					sum += i;
				}
				
			}
			if(sum==num)
			{
				System.out.println(num);
			}
		}
	}

}
