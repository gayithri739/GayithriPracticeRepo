package LoopingAssignment;

import java.util.Scanner;

public class Q9 {

	public static void main(String[] args) {
		
		System.out.println("Enter the character");
		Scanner sc=new Scanner(System.in);
		char ch=sc.next().charAt(0);
		
		if(ch>='A' && ch<='Z')
		{
			if(ch=='A'||ch=='E'||ch=='I'||ch=='O'||ch=='U')
			{
				System.out.println("Entered character is uppercase vowel");
			}
			else
			{
				System.out.println("Entered character is uppercase consonant");	
			}
			
		}
		else if(ch>='a' && ch<='z')
		{
			if(ch=='a'||ch=='e'||ch=='i'||ch=='0'||ch=='u')
			{
				System.out.println("Entered character is lowercase vowel");
			}
			else
			{
				System.out.println("Entered character is lowercase consonant");
			}
		}
		
		

	}

}
