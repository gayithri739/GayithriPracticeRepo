package LoopingAssignment;

import java.util.Scanner;

public class Q16 {

	public static void main(String[] args) {
		
	int sum=0;
		int num;
		Scanner sc=new Scanner(System.in);
		
		do
		{
			System.out.print("Enter a number : ");
			num=sc.nextInt();
			if(num>=0 && num%2==0)//14>=0 14%2=0//number =12 12%2 =0 //Identify even num bers
			{
				sum=sum+num;//0+14=14//14+12=26   //Adding even numbers
			}
		}while(num>=0);//14>=0 //Loop stop when negative number entered
		
		System.out.println("Sum of even numbers : " + sum);                                                                                                                                                                                                                                               
		sc.close();

	}

}
		
	
		        
		   
	
		