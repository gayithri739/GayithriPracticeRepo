package LoopingAssignment;

import java.util.Scanner;

public class Q14 {

	public static void main(String[] args) {
	
		System.out.println("Enter the number of terms as N");
		
		Scanner sc=new Scanner(System.in);
		int n=sc.nextInt();
		
		int count=0;
		int num1=0;
		int num2=1;
		while(count<n)
		{
			if(num1>500) 
			{
				break;
			}
			System.out.print(num1 +" ");
			
			int num3=num1+num2;
			num1=num2;
			num2=num3;
			count++;
		}
		
	}

}
