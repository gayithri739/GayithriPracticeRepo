package LoopingAssignment;

public class Q1IfStatement {

	public static void main(String[] args) {
		int num=93;
		if(num % 3==0 && num % 5!=0 && num>=50 && num<=200)
		{
			System.out.println("valid");
		}
		else
		{
			System.out.println("invalid");
		}
		
	}

}
