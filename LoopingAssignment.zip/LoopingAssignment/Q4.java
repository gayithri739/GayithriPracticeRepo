package LoopingAssignment;

import java.util.Scanner;

public class Q4 {

	public static void main(String[] args) {
		Scanner sc=new Scanner(System.in);
		System.out.println("Enter the number");
		
		int num= sc.nextInt();
		
		if((num>0 && num % 4==0)||(num<0 && num % 6==0))
		{
			System.out.println("It is a valid");
		}
		else
		{
			System.out.println("It is a Invalid");
		}
	}

}


























