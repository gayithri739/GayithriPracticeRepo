package LoopingAssignment;

import java.util.Scanner;

public class Q15 {

	public static void main(String[] args) {
		System.out.println("Enter the number of terms as N");
		Scanner sc=new Scanner(System.in);
		int n=sc.nextInt();
		
		int count=1;
		int num=1;
		int value=1;
		
		while(count<=n)//1<=15//2<=15//3<=15//4<=15
		{
			System.out.print(num +" ");//1//2//4//7
			num=num+value;//1+1=2//2+2=4//4+3=7//7+4=11
			value++;//2//3//4//
			count++;//2//3//4//
		}
	}

}
