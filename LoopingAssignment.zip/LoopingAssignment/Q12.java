package LoopingAssignment;

import java.util.Scanner;

public class Q12 {

	public static void main(String[] args) {
		int rev=0;
		System.out.println("Enter the number");
		Scanner sc=new Scanner(System.in);
		int num=sc.nextInt();//123
		
		while(num>0)//123>0
		{
			int digit=num % 10;//123%10=3 
			
			if (digit==0)//3==0 f//2==0 f//1==0 f//0==0
			{
				break;
			}
			rev=rev*10+digit;//rev=0*10+3=3//rev=0*10+2=2//0*10+1=1
			num=num/10;//num=123/10=12//12/10=1//1/10=0
		}
		System.out.println("Reverse of the number " +rev);
	}

}
