package LoopingAssignment;

public class Q23 {

	public static void main(String[] args) {
		for(int i=1;i<=5;i++)//i=1 1<=5 //2 2<=5
		{
			for(int j=1;j<=i;j++)//j=1 1<=1//2<=1f//2<=2f
			{
				if(j==3)
				{
					continue;
				}
				System.out.print(j);//1
				}
			System.out.println();//nextline
		}
	}

}
