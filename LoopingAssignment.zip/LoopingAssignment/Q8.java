package LoopingAssignment;

import java.util.Scanner;

public class Q8 {

	public static void main(String[] args) {
		int age,salary;
		Scanner sc=new Scanner(System.in);
		System.out.println("Enter the age");
		age=sc.nextInt();
		
		System.out.println("Enter the salary");
		salary=sc.nextInt();
		
		if(age < 25)
		{
			System.out.println("Not eligible");
		}
		else
		{
			if(age >= 30)
			{
				if(salary >= 50000)
				{
					System.out.println("Eligible for loan B");
				}
				else
				{
					if(salary < 30000)
					{
					System.out.println("Eligible for loan A");
					}
					else
					{
						System.out.println("Not eligible");
					}
		
				}
			}
				
		else
			
		{
			if(salary >= 30000)
				{
					System.out.println("Eligible for loan A");
				}
				else
				{
					System.out.println("Not eligible");
				}
			}
		}
	}
}



