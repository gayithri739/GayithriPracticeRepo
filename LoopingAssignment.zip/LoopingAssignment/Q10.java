package LoopingAssignment;

import java.util.Scanner;

public class Q10 {

	public static void main(String[] args) {

	
		System.out.println("Enter the number");
		Scanner sc=new Scanner(System.in);
		
		int num=sc.nextInt();
		
		if(num>=100 && num<=999)
		{
			int sum=(num / 100)+ (num / 10) % 10+(num % 10);
			
			if((sum % 2)==0)
			{
				System.out.println("Entered number is 3 digit and sum is even");
			}
			else
			{
				System.out.println("Entered number is 3 digit and sum is odd");
			}
		}
		else
		{
			System.out.println("Entered number is not a 3 digit number");
		}
		
	}	
	
	
}
