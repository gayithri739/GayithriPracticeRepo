package LoopingAssignment;

import java.util.Scanner;

public class Q19 {

	public static void main(String[] args) {
	int num1;
	int num2;
	int choice=0;
	int Result;
	Scanner sc=new Scanner(System.in);
	do
	{
		System.out.println("****Menu driven*****");
		System.out.println("1. Add ");
		System.out.println("2. Subtract ");
		System.out.println("3. Multiplication");
		System.out.println("4. Exit ");
		System.out.println("Enter your choice");
		
		 choice=sc.nextInt();
		 if(choice>=1 && choice<=3)
		 {
			 System.out.println("Enter first number : ");
			 num1=sc.nextInt();
			 
			 System.out.println("Enter second number : ");
			 num2=sc.nextInt();
			 
			 if(choice==1)
			 {
				 Result=num1 + num2;
				 System.out.println(Result);
			 }
			 else if(choice==2) 
			 {
				 Result=num1 - num2;
				 System.out.println(Result);
			 }
			 else if(choice==3)
			 {
				 Result=num1 * num2;
				 System.out.println(Result);
			 }
		 }
		 else if(choice==4)	
		 {
			 System.out.println("Exit from program ");
			 break;
		 }
		 else
		 {
			 System.out.println("invalid choice, Try again");
		 }
		
	}while(choice!=4);
	
	sc.close();
	}
}
	



