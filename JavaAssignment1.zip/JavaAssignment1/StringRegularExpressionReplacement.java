package JavaAssignment1;

public class StringRegularExpressionReplacement {

	public static void main(String[] args) {
		String str="@#$%1234abcdAbcd";
		
		//Remove all the letters and digits
		//str=str.replaceAll("[a-zA-Z0-9]", "");
		//System.out.println(str);//Output :@#$%
		
		//Remove all the special characters
		//str=str.replaceAll("[^a-zA-Z0-9]", "");
		//System.out.println(str);//1234abcdABCD
		
		//Fetch only alphabets
		//str=str.replaceAll("[^a-zA-Z]", "");
		//System.out.println(str);//1234abcdABCD
		
		//Fetch only digits
		str=str.replaceAll("[^0-9]", "");
		System.out.println(str);//1234abcdABCD
		
		
		
		

	}

}
