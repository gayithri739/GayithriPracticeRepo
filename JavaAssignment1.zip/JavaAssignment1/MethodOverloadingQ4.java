package JavaAssignment1;
class Calculator 
{
	int add()
	{
		return 0;
	}
	int add(int a,int b)
	{
		return a+b;
	}
	double add(double a, double b)
	{
		return a+b;
	}

}
public class MethodOverloadingQ4 {

	public static void main(String[] args) {
		Calculator calc=new Calculator();
		System.out.println(calc.add());
		System.out.println(calc.add(12,15));
		System.out.println(calc.add(12.5,163.6));
		
	}

}
