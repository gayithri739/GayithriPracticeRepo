package JavaAssignment1;
class GovernmentRules 
{
	final int MAX_WORKING_HOURS = 8;
/*	void display()
	{
		MAX_WORKING_HOURS=10;
	}*/

}

public class FinalQ22 {
	
	public static void main(String[] args) {
		GovernmentRules gr=new GovernmentRules();
		gr.MAX_WORKING_HOURS=10;
		
	}

}
